<?php
include ("configure-form.php");
if($_SERVER["REQUEST_METHOD"] == "POST"){
    
    $name = $_POST["Name"];
    $address = $_POST["Address"];
    $phone_Number = $_POST["Phone_Number"];
    $gender = $_POST["Gender"];
    $age = $_POST["Age"];
    $destination = $_POST["Destination"];
    $from = $_POST["From"];
    
    $sql = "INSERT INTO `Form`(`Name`, `Address`, `Phone_Number`, `Gender`, `Age`, `Destination`, `From`) 
    VALUES ('$name','$address','$phone_Number','$gender','$age','$destination','$from')";
    $result = mysqli_query($link,$sql);
    if($result == true){
        echo "submitted";
    }
    else{
        echo "error!!!";
    }
}


?> 

<!DOCTYPE html>
<html lang = "en">
    <head>
        <meta charset = 'UTF-8'>
        <meta name = "viewport" content = "width=device-width, initial-scale = 1.0">
        <title>Form</title>
        <link href="css/stylee.css" rel="stylesheet">
        <link rel="canonical" href="https://getbootstrap.com/docs/3.4/examples/starter-template/">

</head>

<body>
    <div1>
    <h1>KSRTC Form</h1>
    <form method = "POST">
    <span class="border border-light"></span>

    <form class="form-horizontal">
  <div class="form-group">
    <label for="inputEmail3" class="form-control input-lg">Name</label>
    <div class="col-lg-4">
      <input type="text" name = "Name" class="form-control input-lg" id="inputEmail3" placeholder="Name">
    </div>
  </div><br>
        <!-- <label> Name</label>
        <input type = "text" name = "Name"> -->
        <form class="form-horizontal">
            
  <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Address</label>
    <div class="col-sm-50">
      <input type="text" name = "Address" class="form-control" id="inputEmail3" placeholder="Address">
    </div>
  </div><br>
        <!-- <br><br> -->
        <!-- abel<l>Address </label>
        <input type = " text" name = "Address" >
        <br><br> -->
        <form class="form-horizontal">
        <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Phone Number </label>
    <div class="col-sm-50">
      <input type="text" name = "Phone_Number"class="form-control" id="inputEmail3" placeholder="Phone Number ">
    </div>
  </div><br>
        <!-- <label>Phone Number </label>
        <input type = " text" name = "Phone_Number" >
        
        <br><br> -->
        <form class="form-horizontal">
        <label for="Gender">Gender</label>
  <select name="Gender" id="Gender">
    <option value="Male">Male</option>
    <option value="Female">Female</option>
    <option value="Others">Others</option>
 </select><br>
 <!-- <form class="form-horizontal">
 <label for="Gender">Gender</label>
 <select name="Gender" id="Gender">
 <input type = " text" name = "Gender" >
 <div class="checkbox">
  <label>
    <input type="checkbox" value="">
    Male
  </label>
</div>
<div class="checkbox">
  <label>
    <input type="checkbox" value="" >
    Female
  </label> -->
</div><br>
        <!-- <label>Gender </label>
        <input type = " text" name = "Gender" > -->
        <!-- <label>Age </label>
        <input type = " text" name = "Age" >
        <br><br> -->
        <form class="form-horizontal">
        <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Age</label>
    <div class="col-sm-50">
      <input type="text" name = "Age" class="form-control" id="inputEmail3" placeholder="Age">
    </div>
  </div><br>
  <form class="form-horizontal">
        <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Destination</label>
    <div class="col-sm-50">
      <input type="text" name = "Destination" class="form-control" id="inputEmail3" placeholder="Destination">
    </div>
  </div><br>
  <form class="form-horizontal">
        <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">From </label>
    <div class="col-sm-50">
      <input type="text" name = "From" class="form-control" id="inputEmail3" placeholder="From ">
    </div>
  </div><br>
        <!-- <label>Destination </label>
        <input type = " text" name = "Destination" >
        <br><br> -->
        <!-- <label>From  </label>
        <input type = " text" name = "From" > <br><br><br> -->
        <button type="submit" class="btn btn-default" >Submit</button>
</div1>
</form>
<!-- Bootstrap core JavaScript
    ================================================== -->
    <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha384-nvAa0+6Qg9clwYCGGPpDQLVpLNn0fRaROjHqs13t4Ggj3Ez50XnGQqc/r8MhnRDZ" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="js/vendor/jquery.min.js"><\/script>')</script>
    <script src="js/bootstrap.js"></script>
</body>

</html>